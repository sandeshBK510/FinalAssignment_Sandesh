package com.file.in;

import java.util.Scanner;

public class Assignmentclass {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number ::");
		int num = sc.nextInt();
		
		sc.close();
		
		try {
			
			
			  if (num<0) { 
				  
				  throw new Exception ("negaive numbers not allowed"); 
			  
			  }else {
				  System.out.println("Enter number is "+num);
			  }
			 
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		

	}

}

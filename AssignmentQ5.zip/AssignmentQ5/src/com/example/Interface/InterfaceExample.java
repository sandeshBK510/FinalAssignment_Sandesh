package com.example.Interface;



interface Animal {
    void eat();
    void sleep();
}

class Dog implements Animal {
    public void eat() {
        System.out.println("Dog eats.");
    }

    public void sleep() {
        System.out.println("Dog sleeps.");
    }
}

class Cat implements Animal {
    public void eat() {
        System.out.println("Cat eats.");
    }

    public void sleep() {
        System.out.println("Cat sleeps.");
    }
}

public class InterfaceExample {

	public static void main(String[] args) {
		 Dog dog = new Dog();
	        dog.eat();
	        dog.sleep();

	        Cat cat = new Cat();
	        cat.eat();
	        cat.sleep();
		

	}

}

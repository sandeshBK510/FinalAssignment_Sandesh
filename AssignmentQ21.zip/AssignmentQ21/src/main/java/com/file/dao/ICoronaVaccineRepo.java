package com.file.dao;

import org.springframework.data.repository.CrudRepository;

import com.file.Bo.CoronaVacine;

public interface ICoronaVaccineRepo extends CrudRepository<CoronaVacine, Long> {

}

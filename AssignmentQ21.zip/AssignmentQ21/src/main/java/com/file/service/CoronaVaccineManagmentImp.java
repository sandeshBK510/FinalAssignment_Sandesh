package com.file.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.file.Bo.CoronaVacine;
import com.file.dao.ICoronaVaccineRepo;


@Service("service")
public class CoronaVaccineManagmentImp implements ICoronaVaccineMangementService {
    
	
	@Autowired
	private ICoronaVaccineRepo repo;
	
	
	@Override
	public String registerVaccine(CoronaVacine vaccine) {
		System.out.println("In Memory proxy class"+repo.getClass().getName());
		
		
		CoronaVacine saveVaccine = null;
		if (vaccine != null) {
			
			saveVaccine = repo.save(vaccine);
			
		}
		
		return saveVaccine!=null ?"vaccine registred sucessfully with"+saveVaccine.getRegNo():"vaccine registration failed";
	}


	@Override
	public Iterable<CoronaVacine> registerInBatch(Iterable<CoronaVacine> vaccines) {

		if (vaccines != null) {
			return repo.saveAll(vaccines);
		}else {
			throw  new IllegalArgumentException("batch insertion failed");
		}
		
		
	}


	@Override
	public Long getVaccineCount() {
		// TODO Auto-generated method stub
		return repo.count();
	}


	@Override
	public boolean checkExist(Long regNo) {
		// TODO Auto-generated method stub
		return repo.existsById(regNo);
	}


	@Override
	public Iterable<CoronaVacine> fetchAllDetail() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}


	@Override
	public Iterable<CoronaVacine> fetchAllDetailById(List<Long> ids) {
		// TODO Auto-generated method stub
		return repo.findAllById(ids);
	}


	
}

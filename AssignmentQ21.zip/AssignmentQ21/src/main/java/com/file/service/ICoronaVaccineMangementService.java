package com.file.service;

import java.util.List;

import com.file.Bo.CoronaVacine;

public interface ICoronaVaccineMangementService {
	
	public String registerVaccine(CoronaVacine vaccine);
	public Iterable<CoronaVacine> registerInBatch(Iterable<CoronaVacine> vaccines);
	public Long getVaccineCount();
	public boolean checkExist(Long regNo);
	public Iterable<CoronaVacine>fetchAllDetail();
	public Iterable<CoronaVacine> fetchAllDetailById(List<Long> ids);
		
	

}

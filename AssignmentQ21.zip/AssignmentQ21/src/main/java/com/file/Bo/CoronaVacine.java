package com.file.Bo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class CoronaVacine implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private Long regNo;
	private String name;
	private String company;
	private String country;
	private double price;
	private Integer requiredDosage;
	
	
	
		
	
	public CoronaVacine() {
	}




	public CoronaVacine(Long regNo, String name, String company, String country, double price, Integer requiredDosage) {
		
		this.regNo = regNo;
		this.name = name;
		this.company = company;
		this.country = country;
		this.price = price;
		this.requiredDosage = requiredDosage;
	}




	public Long getRegNo() {
		return regNo;
	}




	public void setRegNo(Long regNo) {
		this.regNo = regNo;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getCompany() {
		return company;
	}




	public void setCompany(String company) {
		this.company = company;
	}




	public String getCountry() {
		return country;
	}




	public void setCountry(String country) {
		this.country = country;
	}




	public double getPrice() {
		return price;
	}




	public void setPrice(double price) {
		this.price = price;
	}




	public Integer getRequiredDosage() {
		return requiredDosage;
	}




	public void setRequiredDosage(Integer requiredDosage) {
		this.requiredDosage = requiredDosage;
	}




	@Override
	public String toString() {
		return "CoronaVacine [regNo=" + regNo + ", name=" + name + ", company=" + company + ", country=" + country
				+ ", price=" + price + ", requiredDosage=" + requiredDosage + "]";
	}
	
	

}

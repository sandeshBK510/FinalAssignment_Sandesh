package com.file;

import java.util.ArrayList;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.file.Bo.CoronaVacine;
import com.file.service.ICoronaVaccineMangementService;

import ch.qos.logback.core.net.SyslogOutputStream;

@SpringBootApplication
public class DaoSpringDataJpa01Application {

	public static void main(String[] args) {
		ApplicationContext factory = SpringApplication.run(DaoSpringDataJpa01Application.class, args);
		
		
		ICoronaVaccineMangementService service = factory.getBean(ICoronaVaccineMangementService.class);
		
		/*
		 * System.out.println(service.checkExist(3L));
		 * System.out.println("total vaccine count"+service.getVaccineCount());
		 */
		
//		 ArrayList<CoronaVacine> vaccines = new ArrayList<CoronaVacine>();
//		 vaccines.add(new CoronaVacine(null, "sutnik", "russi", "Russia", 605.5, 4));
//		 vaccines.add(new CoronaVacine(null, "phyzer", "phywer", "USA", 800.5, 5));
//		 vaccines.add(new CoronaVacine(null, "moderena", "moderena ", "USA", 405.5, 6));
//		
//		Iterable<CoronaVacine> listVaccines = service.registerInBatch(vaccines);
//		
//		listVaccines.forEach(vaccine->System.out.println(vaccine.getRegNo()));
		
//		service.fetchAllDetail().forEach(System.out::println);
		
		
	
		
		((ConfigurableApplicationContext)factory).close();
	}

}

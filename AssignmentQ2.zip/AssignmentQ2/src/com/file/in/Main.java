package com.file.in;


 class Car{
	 
	public Car() {
		super();
		System.out.println("car is manufactureed");
		
		
	}



	
	
	
	 
	 
}
 class Mahendra extends Car {

	public Mahendra() {
		super();
		System.out.println("Mahindra is the manufacturer of the car ");
		
		
	}
	 
 }
public class Main {

	public static void main(String[] args) {

		Mahendra mahindra = new Mahendra();
;	
	}

}

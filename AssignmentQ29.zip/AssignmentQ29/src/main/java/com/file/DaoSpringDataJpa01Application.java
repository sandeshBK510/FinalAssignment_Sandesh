package com.file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.file.Bo.CoronaVacine;
import com.file.service.ICoronaVaccineMangementService;

@SpringBootApplication
public class DaoSpringDataJpa01Application {

	public static void main(String[] args) {
		ApplicationContext factory = SpringApplication.run(DaoSpringDataJpa01Application.class, args);
		
		
		ICoronaVaccineMangementService service = factory.getBean(ICoronaVaccineMangementService.class);
		
		CoronaVacine vaccine = new CoronaVacine(null,  "covishield", "serum", "IND", 743.0, 2);
		
		service.searchVaccineByGivenData(vaccine, true, "price").forEach(System.out::println);
	
		
		((ConfigurableApplicationContext)factory).close();
	}

}

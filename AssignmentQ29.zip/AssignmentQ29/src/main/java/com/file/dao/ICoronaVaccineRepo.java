package com.file.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.file.Bo.CoronaVacine;

public interface ICoronaVaccineRepo extends JpaRepository<CoronaVacine, Long> {
	
	

}

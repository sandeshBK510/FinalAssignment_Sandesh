package com.file.service;

import java.util.List;

import com.file.Bo.CoronaVacine;

public interface ICoronaVaccineMangementService {
	
	public List<CoronaVacine> searchVaccineByGivenData(CoronaVacine vaccine,boolean ascOrder,String properties);
	

}

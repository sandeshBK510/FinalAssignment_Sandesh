package com.file.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.file.Bo.CoronaVacine;
import com.file.dao.ICoronaVaccineRepo;


@Service("service")
public class CoronaVaccineManagementImp implements ICoronaVaccineMangementService {
	
	@Autowired
	private ICoronaVaccineRepo repo;

	@Override
	public List<CoronaVacine> searchVaccineByGivenData(CoronaVacine vaccine, boolean ascOrder, String properties) {
		
		
		Sort sort = Sort.by(ascOrder ? Direction.ASC:Direction.DESC, properties);
		Example<CoronaVacine> example = Example.of(vaccine);
		List<CoronaVacine> findAll = repo.findAll(example, sort);
		return findAll;
	}
	
	

}

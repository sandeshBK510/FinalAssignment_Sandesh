package in.hebernate.test;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;

import in.hibernate.Util.HibernateUtil;
import in.hibernate.model.EmployeeTable;

public class SelectApp {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		
		Session session =null;
		
		try {
		
		session =HibernateUtil.getSession();
		
		
		Query<EmployeeTable> query = session.createQuery("from in.hibernate.model.EmployeeTable"); 
		
		List<EmployeeTable> resultList = query.getResultList();
		
		resultList.forEach(System.out::println);
		
		
		}catch(HibernateException he) {
			
			he.printStackTrace();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			HibernateUtil.closeSession(session);
			HibernateUtil.closeSessionFactory();
			
		}

	}

}

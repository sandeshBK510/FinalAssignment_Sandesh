package in.assignment;


import java.util.Arrays;
import java.util.List;

public class StreamApiExample {

	public static void main(String[] args) {
		List<Integer> num = Arrays.asList(5, 8, 2, 4, 1, 9, 3, 7, 6);
		
		System.out.println("Sorted numbers are");
		num.stream().sorted().forEach(System.out::println);
		
		System.out.println();
		
		//Filtering the even numbers 
		System.out.println("the even numbers are ::");
		num.stream().filter(n->n%2==0).forEach(System.out::println); 
	}

}

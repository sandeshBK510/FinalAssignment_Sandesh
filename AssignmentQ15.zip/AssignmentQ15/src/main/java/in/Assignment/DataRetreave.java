package in.Assignment;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class DataRetreave
 */
@WebServlet("/data")
public class DataRetreave extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		
		   String jdbcDriver = "com.mysql.cj.jdbc.Driver";
		  String url = "jdbc:mysql:///mydb";
	      String user = "root";
	      String password = "sandesh";
	      
	      Connection connection = null;
	      Statement statement = null;
	      ResultSet resultSet = null;
		
	     try {
	    	 
	    	 Class.forName(jdbcDriver);
			connection = DriverManager.getConnection(url,user,password);
			
			statement=connection.createStatement();
			
			String sqlQuery = "SELECT * FROM mydb.details";
			
			resultSet = statement.executeQuery(sqlQuery);			
			
			out.println("<table>");
            out.println("<tr><th>ID</th><th>NAME</th><th>PHONE NUMBER</th></tr>");
            
            
            while (resultSet.next()) {
				
            	int id = resultSet.getInt("id");
            	String name = resultSet.getString("name");
            	int number = resultSet.getInt("number");
            	
            	out.println("<tr><td>" + id + "</td><td>" + name + "</td></tr>"+number+"</td></tr>");
			}
            out.println("</table>");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
		}
	     out.println("</body></html>");
		
	}

}

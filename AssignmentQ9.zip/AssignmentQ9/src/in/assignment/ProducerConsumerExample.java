package in.assignment;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class ProducerConsumerExample {
	
	private static final int MAX_QUEUE_SIZE = 10;
    private static final int MAX_RANDOM_NUMBER = 100;
    private static final int MAX_NUMBERS_TO_GENERATE = 20;

    private static Queue<Integer> queue = new LinkedList<>();
    private static Object lock = new Object();

    public static void main(String[] args) {
        Thread producerThread = new Thread(new Producer());
        Thread consumerThread = new Thread(new Consumer());

        producerThread.start();
        consumerThread.start();
    }

    static class Producer implements Runnable {
        private Random random = new Random();

        public void run() {
            for (int i = 0; i < MAX_NUMBERS_TO_GENERATE; i++) {
                try {
                    Thread.sleep(random.nextInt(2000)); // Simulate random production time
                    int number = random.nextInt(MAX_RANDOM_NUMBER);
                    produce(number);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        private void produce(int number) throws InterruptedException {
            synchronized (lock) {
                while (queue.size() == MAX_QUEUE_SIZE) {
                    lock.wait(); // Wait if the queue is full
                }

                queue.offer(number);
                System.out.println("Produced: " + number);

                lock.notifyAll(); // Notify the consumer that a number is added to the queue
            }
        }
    }

    static class Consumer implements Runnable {
        public void run() {
            int sum = 0;

            for (int i = 0; i < MAX_NUMBERS_TO_GENERATE; i++) {
                try {
                    Thread.sleep(1000); // Simulate fixed consumption time
                    int number = consume();
                    sum += number;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            System.out.println("Sum of consumed numbers: " + sum);
        }

        private int consume() throws InterruptedException {
            synchronized (lock) {
                while (queue.isEmpty()) {
                    lock.wait(); // Wait if the queue is empty
                }

                int number = queue.poll();
                System.out.println("Consumed: " + number);

                lock.notifyAll(); // Notify the producer that a number is consumed from the queue

                return number;
            }
        }
    }

}

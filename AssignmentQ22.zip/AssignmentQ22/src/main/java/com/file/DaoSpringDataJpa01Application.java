package com.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Reader;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import com.file.Bo.MarraigeSeeker;
import com.file.service.IMatrimonyServiceManagment;



@SpringBootApplication
public class DaoSpringDataJpa01Application {

	public static void main(String[] args) throws IOException {
		ApplicationContext factory = SpringApplication.run(DaoSpringDataJpa01Application.class, args);
		
		IMatrimonyServiceManagment service = factory.getBean(IMatrimonyServiceManagment.class);
	    
		/*
		 * Scanner sc = new Scanner(System.in);
		 * 
		 * System.out.println("Enter the name::"); String name = sc.next();
		 * System.out.println("Enter the address::"); String address = sc.next();
		 * System.out.println("Enter the photoPath"); String photo = sc.next();
		 * System.out.println("Enter the bioDataPath"); String bioDataPath = sc.next();
		 * 
		 * System.out.println("is the persion Indian"); Boolean indian =
		 * sc.nextBoolean();
		 * 
		 * FileInputStream inputStream = new FileInputStream(photo); byte [] photoData =
		 * new byte[inputStream.available()]; inputStream.read(photoData);
		 * 
		 * File file = new File(bioDataPath); Reader reader = new FileReader(file);
		 * char[] bioDataContent = new char[(int)file.length()];
		 * 
		 * MarraigeSeeker seeker = new MarraigeSeeker(name, address, photoData,
		 * LocalDateTime.of(2001, 1, 3, 20, 15), bioDataContent, indian);
		 * 
		 * 
		 * System.out.println(service.RegesterMarraigeSeeker(seeker));
		 * 
		 * inputStream.close(); reader.close(); sc.close();
		 */
		
		Optional<MarraigeSeeker> seekerId = service.searchBySeekerId(1L);
		if (seekerId.isPresent()) {
			
			MarraigeSeeker seeker = seekerId.get();
			System.out.println(seeker.getId()+" "+seeker.getName()+" "+seeker.getSaddress()+""+seeker.isIndian());
			
			OutputStream outputStream = new FileOutputStream("retreave_image.jpg");
			
			outputStream.write(seeker.getPhoto());
			outputStream.flush();
			
			FileWriter writer = new FileWriter("retereave_file.txt");
			writer.write(seeker.getBioData());
			writer.flush();
			
			outputStream.close();
			writer.close();
			
			System.out.println(	"lobs are retrived");
			
		} else {
			
			System.out.println("record not found ");

		}
		
		((ConfigurableApplicationContext)factory).close();
	}

}

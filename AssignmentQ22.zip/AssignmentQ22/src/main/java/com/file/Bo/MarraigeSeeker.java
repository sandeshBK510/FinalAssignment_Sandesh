package com.file.Bo;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import lombok.Data;
import lombok.NonNull;


@Entity
@Data
public class MarraigeSeeker implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@NonNull
	private String name;
	@NonNull
	private String saddress;
	
	
	@Lob
	@NonNull
	private byte[] photo;
	@NonNull
	private LocalDateTime dob ;
	
	@Lob
	@NonNull
	private char[] bioData;
	@NonNull
	private boolean indian;

}

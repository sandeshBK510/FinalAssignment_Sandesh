package com.file.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.file.Bo.MarraigeSeeker;
import com.file.dao.IMarrageRepo;


@Service("service")
public class MarraigeSeekerImp implements IMatrimonyServiceManagment {

	@Autowired
	private IMarrageRepo repo;
	
	  
	@Override
	public String RegesterMarraigeSeeker(MarraigeSeeker seeker) {
		return "Marraige seeker id is saved in the id"+repo.save(seeker).getId() ;
	}

	@Override
	public Optional<MarraigeSeeker> searchBySeekerId(Long id) {
		return repo.findById(id);
	}

}

package com.file.service;

import java.util.Optional;

import com.file.Bo.MarraigeSeeker;

public interface IMatrimonyServiceManagment {
	public String RegesterMarraigeSeeker(MarraigeSeeker seeker);
	public Optional<MarraigeSeeker> searchBySeekerId(Long id);

}

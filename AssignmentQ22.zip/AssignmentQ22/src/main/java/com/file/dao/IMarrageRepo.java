package com.file.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.file.Bo.MarraigeSeeker;

public interface IMarrageRepo extends PagingAndSortingRepository<MarraigeSeeker, Long> {

}

package com.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaoSpringDataJpa01ApplicationTests {

	@Test
	void contextLoads() {
	}

}

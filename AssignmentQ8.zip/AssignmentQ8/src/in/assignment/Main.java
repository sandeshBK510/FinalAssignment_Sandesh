package in.assignment;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        List<Integer> numbers = Arrays.asList(10, 5, 20, 3, 15, 8, 25, 30, 12, 18);

        List<Integer>  sortedNumber = Arrays.stream(numbers.toArray(new Integer[0])).sorted().collect(Collectors.toList());
        System.out.println("sorted elements"+sortedNumber);

        List<Integer> filterNumber = Arrays.stream(numbers.toArray(new Integer[0])).filter(n-> n<15).collect(Collectors.toList());
        System.out.println("filtered Elements"+filterNumber);


    }
}
package in.assignment;

public class EvenOddThread {
    public static void main(String[] args) {

        Thread thread1 = new Thread(()->{
            for (int i = 0; i < 10; i++) {
                if (i%2 ==0){
                    System.out.println(i);
                }
            }
        });
        Thread thread2 = new Thread(()->{
            for (int i = 1; i < 10; i++) {
                if (i%2!=0){
                    System.out.println(i);
                }
            } 
        });

        thread1.start();
        thread2.start();
    }

}

package in.assignment;

public class ThreadEvenOdd {

    static class EvenRunnable implements Runnable{
        @Override
        public void run() {
            for (int i = 0; i < 10; i++) {
                if (i%2==0)
                    System.out.println(i);
            }
        }
    }
    static class OddRunnable implements Runnable{
        @Override
        public void run() {
            for (int i = 1; i < 10; i++) {
                if (i%2 !=0)
                    System.out.println(i);
            }
        }
    }

    public static void main(String[] args) {
        Thread t1 = new Thread(new EvenRunnable());
        Thread t2 = new Thread(new OddRunnable());

        t1.start();
        t2.start();
    }
}

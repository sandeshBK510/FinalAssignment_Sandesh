package com.project.file;

public class Triangle implements IShape {
	
	private int side1;
	private int side2;
	private int side3;
	
	

	public Triangle(int side1, int side2, int side3) {
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}

	@Override
	public double calculatreArea() {
		
		double sp = (side1+side2+side3)/2;
		return Math.sqrt(sp*(sp-side1)*(sp-side2)*(sp-side3));
	}

	@Override
	public double calculateParameter() {
		// TODO Auto-generated method stub
		return side1+side2+side3;
	}

}

package com.project.file;

public class Main {

	public static void main(String[] args) {
		
		
		Circle circle = new Circle(20);
		
		System.out.println("the area of the circle is ::"+circle.calculatreArea());
		System.out.println("the perimeter of the circle is ::"+circle.calculateParameter());
		
		Triangle triangle = new Triangle(40, 20, 30);
        
		System.out.println("the area of the triangle is ::"+triangle.calculatreArea());
		System.out.println("the perimeter  of the triangle is ::"+triangle.calculateParameter());
	}

}

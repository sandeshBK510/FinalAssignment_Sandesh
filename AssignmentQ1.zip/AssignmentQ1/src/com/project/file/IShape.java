package com.project.file;

public interface IShape {
	
	public double calculatreArea();
	
	public double calculateParameter();

}

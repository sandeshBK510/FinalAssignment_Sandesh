package com.login.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class MainControlller {
	
	@GetMapping("/")
	public String getLogin() {
		return"login";
	}

}

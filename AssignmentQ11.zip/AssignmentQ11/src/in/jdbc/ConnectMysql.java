package in.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectMysql {

	public static void main(String[] args) throws SQLException {
		
		
		String url = "jdbc:mysql:///mydb";
	      String user = "root";
	      String password = "sandesh";
	      
	      Connection connection = DriverManager.getConnection(url,user,password);
		  
	      Statement statement = connection.createStatement();
	      
	      String sqlSelectQuery = "SELECT * FROM mydb.products";
	      
	      ResultSet resultSet = statement.executeQuery(sqlSelectQuery);
	      System.out.println("ID\tNAME\tPRICE\tQUANTITY");
	      
	      while (resultSet.next()) {
             
	    	  int pid = resultSet.getInt("pid");
	    	  String pname = resultSet.getString("pname");
	    	 int prize = resultSet.getInt("prize");
	    	 int qty = resultSet.getInt("qty");
	    	 
	    	 System.out.println(pid+"\t"+pname+"\t"+prize+"\t"+qty);
	    	 
	    	  
		}
	      resultSet.close();
	      statement.close();
	      connection.close();
	      
	      
	}


}

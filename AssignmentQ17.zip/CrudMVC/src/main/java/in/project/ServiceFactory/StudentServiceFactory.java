package in.project.ServiceFactory;

import in.project.Service.IStudentService;
import in.project.Service.StudentServiceImp;

public class StudentServiceFactory {
	
	private static IStudentService studentService = null;
	
	public static IStudentService getStudentService() {
		
		if (studentService == null) {
			studentService = new StudentServiceImp();
			
		}
		return studentService;
	}

}

package in.project.Dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.project.Dto.Student;
import in.project.Util.JdbcUtil;

public class StudentDaoImp implements IStudentDao {
	
	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	@Override
	public String addStudent(Student student) {
		
		String sqlInsertQuery = "insert into student(`name`,`age`,`address`) values(?,?,?)";
		
		try {
			connection = JdbcUtil.getJdbcConnection();
			
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlInsertQuery);
			}
			
			if (pstmt != null) {
				
				pstmt.setString(1, student.getSname());
				pstmt.setInt(2, student.getSage());
				pstmt.setString(3, student.getSadress());
				
				int rowAffected = pstmt.executeUpdate();
				
				if (rowAffected==1) {
					
					return "success";
					
				}
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "failure";
	}

	@Override
	public Student searchStudent(Integer sid) {
		
		String sqlSearchQuery = "SELECT * FROM student where id=?";
		Student student =null;
		
		try {
			connection = JdbcUtil.getJdbcConnection();
			
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlSearchQuery);
				
			}
			if (pstmt != null) {
				pstmt.setInt(1, sid);
				
			}
			if (pstmt != null) {
				pstmt.executeQuery();
			}
			if (rs != null) {
				
				if(rs.next()) {
					
					 student = new Student();
					 
					 student.setSid(rs.getInt(1));
					 student.setSname(rs.getString(2));
					 student.setSage(rs.getInt(3));
					 student.setSadress(rs.getString(4));
					 
					 return student;
				}
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		return student;
	}

	@Override
	public String updateStudent(Student student) {
		
		String sqlUpdateQuery = "update student set `name`=?,`age`=?,`address`=? where id =?";
		
		try {
			connection = JdbcUtil.getJdbcConnection();
			
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlUpdateQuery);
			}
			if (pstmt != null) {
				pstmt.setInt(1, student.getSid());
				pstmt.setString(2, student.getSname());
				pstmt.setInt(3, student.getSage());
				pstmt.setString(4, student.getSadress());
				
				int rowAffected = pstmt.executeUpdate();
				
				if (rowAffected ==1) {
					return "success";
					
				}
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return "failure";
	}

	@Override
	public String deleteStudent(Integer sid) {
		
		String sqlDeleteQuery = "delete from student where id = ?";

		try {
			connection = JdbcUtil.getJdbcConnection();
			
			if (connection != null) {
				pstmt = connection.prepareStatement(sqlDeleteQuery);
				
			}
			if (pstmt != null) {
				 
				pstmt.setInt(1, sid);
				
		     int rowAffected = pstmt.executeUpdate();
		    		 if (rowAffected ==1) {
		    			 
		    			 return "success";
		    			 
						
					}else {
						return"not found";
						
					}
			}
			
			
			
		} catch (SQLException | IOException e) {
			e.printStackTrace();
			return "failure";
		}
		
		
		
		return "failure";
	}

}

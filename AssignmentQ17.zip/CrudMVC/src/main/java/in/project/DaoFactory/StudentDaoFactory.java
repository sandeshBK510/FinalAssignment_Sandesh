package in.project.DaoFactory;

import in.project.Dao.IStudentDao;
import in.project.Dao.StudentDaoImp;

public class StudentDaoFactory {

	public StudentDaoFactory() {}
	
	private static IStudentDao studentDao = null;
	
	public static IStudentDao getStudentDao () {
		
		if (studentDao == null) {
			studentDao = new StudentDaoImp();
		}
		return studentDao;
	}
	
	

}

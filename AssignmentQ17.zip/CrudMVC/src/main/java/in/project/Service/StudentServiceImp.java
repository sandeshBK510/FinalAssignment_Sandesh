package in.project.Service;

import in.project.Dao.IStudentDao;
import in.project.DaoFactory.StudentDaoFactory;
import in.project.Dto.Student;

public class StudentServiceImp implements IStudentService {
	
	private IStudentDao stdDao = null;

	@Override
	public String addStudent(Student student) {
		
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.addStudent(student);
	}

	@Override
	public Student searchStudent(Integer sid) {
		
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.searchStudent(sid);
	}

	@Override
	public String updateStudent(Student student) {
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.updateStudent(student);
	}

	@Override
	public String deleteStudent(Integer sid) {
		stdDao = StudentDaoFactory.getStudentDao();
		return stdDao.deleteStudent(sid);
	}

}
